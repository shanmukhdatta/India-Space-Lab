# Screenshots — To Be Added

This folder is the destination for the 5 required UI screenshots
(see `../docs/README.md`, Section 4). They must be captured live from
the running dashboard (Demo Sim mode is fine) — that's why they aren't
pre-generated here.

Capture these 5, save as `.png` into this folder:

1. `01_full_dashboard.png` — full dashboard, all six panels visible
2. `02_error_codes_fault.png` — Error Code module with a fault digit lit
3. `03_tracking_map.png` — map with a visible GPS path trail
4. `04_orientation_3d.png` — 3D orientation model mid-rotation
5. `05_mission_control_log.png` — Mission Control panel after a command (SENT → ACK log visible)

Steps: open `../index.html` in Chrome/Edge → turn Demo Sim ON → Start
Telemetry → let it run 60+ seconds → screenshot each panel.
